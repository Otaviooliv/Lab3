
package trab_parcial;

/*
    Esta classe tem função de gerenciar os livros que foram registrados no sistema da biblioteca.

*/
public class Livro extends Usuario{
    
    protected int idlivro;
    protected int anopublicacao;
    protected String titulo;
    protected String autor;
    protected String edicao;
    protected String editora;
    protected String cidade;

    public Livro(){
        
    }

     //Sobrecarregado 1
    public Livro(String titulo) {
        this.titulo = titulo;
    }

     //Sobrecarregado 2
    public Livro(int idlivro, int anopublicacao, String titulo, String autor, String edicao, String editora, String cidade) {
       
        this.idlivro = idlivro;
        this.anopublicacao = anopublicacao;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
    }

    public Livro(int idlivro,String titulo) {
       
        this.idlivro = idlivro;
        this.titulo = titulo;
    }
    
    public int getIdlivro() {
        return idlivro;
    }

    public void setIdlivro(int idlivro) {
        this.idlivro = idlivro;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

   
    @Override
    public String toString() {
        return "ID do livro: " + getIdlivro() + "\n" + "Ano de publicacao: " + getAnopublicacao() + "\n" +  "Titulo: " + getTitulo() + "\n" + "Autor: " + autor + "\n" +"Edicao: " + edicao + "\n" + "Editora: " + editora + "\n" + "Cidade: " + cidade + "\n";
    }
    
    
    
}
