
package trab_parcial;

import java.time.LocalDate;

/*
    Esta classe tem função de gerenciar os livros que foram ou nao devolvidos

*/
public class Emprestimo extends Livro{
    
    protected int idemprestimo;
    protected int idUsuario;
    protected int idLivro;
    protected String dataEmprestimo;
    protected String dataDevolucao;
    protected boolean devolvido;
    

    public Emprestimo(){
        
    }

    //Sobrecarregado 1
    public Emprestimo(int idemprestimo, String dataEmprestimo, String dataDevolucao, boolean devolvido, String titulo) {
        super(titulo);
      
        this.idemprestimo = idemprestimo;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
        
    }
    
    //Sobrecarregado 2
    public Emprestimo(int idlivro, int anopublicacao, String titulo, String autor, String edicao, String editora, String cidade, int idemprestimo, int idUsuario, String dataEmprestimo, String dataDevolucao, boolean devolvido ) {
        super(idlivro, anopublicacao, titulo, autor, edicao, editora, cidade);
        
        this.idemprestimo = idemprestimo;
        this.idUsuario = idUsuario;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }


    public int getIdemprestimo() {
        return idemprestimo;
    }

    public void setIdemprestimo(int idemprestimo) {
        this.idemprestimo = idemprestimo;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public String getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(String dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public boolean isDevolvido() {
        return devolvido;
    }

    public void setDevolvido(boolean devolvido) {
        this.devolvido = devolvido;
        
    }
    
    public String Status(){
        return (devolvido ? "Devolvido" : "Não devolvido");
    }

   @Override
   public String getTitulo(){
       return super.titulo + "(LIVRO FAMOSO)";
   }

    @Override
    public String toString() {
        return super.toString() + "Id do emprestimo: " + idemprestimo + "\n"  + "Data do emprestimo: " + dataEmprestimo + "\n" + "Data da Devolução: " + dataDevolucao + "\n" + "Status do emprestimo: " + Status() + "\n";
    }
    
    
    
    
}
