/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trab_parcial;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author otavi
 */
public class BibliotecaTest {
    
    public static void main(String[] args) {
        
        //Insercao de dados nos contrutores 
        Usuario a = new Usuario();
        a.setEmail("gabriel@gmail.com");
        a.setId(12);
        a.setSenha("gab123");
        a.setNome("Gabriel");
        System.out.println(a);
        
        Livro biblio = new Livro();
        biblio.setAnopublicacao(0);
        biblio.setAutor("Vladímir Nabókov");
        biblio.setCidade("Roma");
        biblio.setEdicao("Segunda Edição");
        biblio.setEditora("Editora Roma");
        biblio.setIdlivro(153);
        biblio.setTitulo("Lolita");
        System.out.println(biblio);
  
        Emprestimo emp = new Emprestimo();
        emp.setIdemprestimo(10);
        emp.setDataDevolucao("15/05/2020");
        emp.setDataEmprestimo("11/05/2020");
        emp.setDevolvido(false);
        System.out.println(emp);
        
        
        //Insercao de dados nos contrutores sobrecarregados 1
        Usuario b = new Usuario(55, "Joana Almeida");
        System.out.println(b);
        
        Livro biblio2 = new Livro(153, "Lolita");
        System.out.println(biblio2);
        
        Emprestimo emp2 = new Emprestimo(105, "10/05/2020", "13/05/2020", true, "Pequeno Principe");
        System.out.println(emp2);
        
        
        
        //Insercao de dados nos contrutores sobrecarregados 2
        //Lista dos usuarios
       List<Usuario> lista = new ArrayList<>();
       
       lista.add(new Usuario(45, "Felipe Medeiros", "felipe157@gmail.com", "FelipeA"));
       lista.add(new Usuario(31, "Antônio Souza", "antsz1010@gmail.com", "Anto1092"));
       lista.add(new Usuario(22, "Pedro Oliveira", "pedrooliv@gmail.com", "pedroo22"));
       lista.add(new Usuario(57, "Cleber Mendença", "clebinho@gmail.com", "scarlight"));
       
       for(Usuario u : lista){
                System.out.println(u + "\n");
        }
         
       //Lista dos livros
        List<Livro> lista2 = new ArrayList<>();   
        
        lista2.add(new Livro(153, 1955, "Lolita", "Vladímir Nabókov","Segunda Edição", "Editora Roma", "Roma"));
        lista2.add(new Livro(879, 1949, "1984", "George Orwell", "Primeira Edição", "Secker and Warburg", "Londres"));
        lista2.add(new Livro(185, 2005, "A menina que roubava livros", "Markus Zusak","Primeira Edição", "Picador", "Alemanha"));
        lista2.add(new Livro(716, 1927, "Rumo ao Farol", "Virginia Woolf","Primeira Edição", "Hogarth Press", "Londres"));
        lista2.add(new Livro(856, 1925, "O Grande Gatsby", "Scott Fitzgerald","Primeira Edição", "Charles Scribner's Sons", "Nova Iorque"));
                    
        for(Livro l : lista2){
           System.out.println(l + "\n");
        }
      
        //Lista dos emprestimos
      List<Emprestimo> lista3 = new ArrayList<>();
     
      lista3.add(new Emprestimo(153, 1955, "Lolita", "Vladímir Nabókov","Segunda Edição", "Editora Roma", "Roma", 100, 45, "17/05/2020", "18/05/2020", false));
      lista3.add(new Emprestimo(879, 1949, "1984", "George Orwell", "Primeira Edição", "Secker and Warburg", "Londres", 101, 31, "14/05/2020", "17/05/2020", true));
      lista3.add(new Emprestimo(185, 2005, "A menina que roubava livros", "Markus Zusak","Primeira Edição", "Picador", "Alemanha", 102, 22, "15/05/2020", "17/05/2020", true));
      lista3.add(new Emprestimo(856, 1925, "O Grande Gatsby", "Scott Fitzgerald","Primeira Edição", "Charles Scribner's Sons", "Nova Iorque", 103, 57, "17/05/2020", "21/05/2020", false));
      
      for(Emprestimo e : lista3){
          System.out.println(e + "\n");
      }
    }
}
